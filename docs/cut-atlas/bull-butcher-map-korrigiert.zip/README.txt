Korrigierte Bullen-Zerlegekarte (Kopf links, anatomisch konsistent, silhouetten-geclippt).

Inhalt:
- BullButcherMap.tsx  -> React/SVG-Komponente (25 Zonen, Hover/Active, clipPath)
- bulle-freigestellt.png -> freigestellter Bulle, nach links gespiegelt (transparent)

Integration (Claude Code):
1. bulle-freigestellt.png nach public/images/ kopieren (ersetzt das nach-rechts-Bild).
2. BullButcherMap.tsx nach src/components/cuts/ legen.
3. Zonen an cuts-catalog.ts koppeln: onZoneClick(zone) -> Cut/Primal per zone.id oder zone.label
   mappen und das Info-Panel/Detail oeffnen.
4. Auf dunklem Hintergrund einbetten; Labels sind #F9FAFB (hell) mit dunkler Kontur.
Aenderung ggue. Original: Bild + Silhouette gespiegelt, Kopf-Zonen (Kopf/Backe/Zunge/Hals)
gespiegelt -> Vorder-/Hinterviertel jetzt anatomisch korrekt.
